// src/background/keepalive.ts
var KEEPALIVE_ALARM = "cap-keepalive";
var KEEPALIVE_INTERVAL_MINUTES = 1;
function startKeepAlive() {
  chrome.alarms.create(KEEPALIVE_ALARM, {
    periodInMinutes: KEEPALIVE_INTERVAL_MINUTES
  });
}
function stopKeepAlive() {
  chrome.alarms.clear(KEEPALIVE_ALARM);
}
function isKeepAliveAlarm(alarmName) {
  return alarmName === KEEPALIVE_ALARM;
}

// src/shared/config.ts
var extensionEnv = globalThis.process?.env;
var fallbackApiBaseUrl = "https://capweb-production-dd85.up.railway.app";
var DEFAULT_API_BASE_URL = [
  extensionEnv?.WEB_URL,
  extensionEnv?.NEXT_PUBLIC_WEB_URL,
  fallbackApiBaseUrl
].map((value) => value?.trim()).find((value) => Boolean(value)) ?? fallbackApiBaseUrl;

// src/background/state.ts
var STATE_KEY = "capExtState";
var SETTINGS_KEY = "capExtSettings";
var DEFAULT_SETTINGS = {
  apiBaseUrl: DEFAULT_API_BASE_URL,
  apiKey: "",
  autoRecordOnMeet: false,
  autoRecordCountdownSec: 5,
  micDeviceId: "",
  micEnabled: true,
  captureMode: "picker",
  soundEnabled: true,
  cameraOverlay: false,
  cameraDeviceId: ""
};
async function getState() {
  const result = await chrome.storage.local.get(STATE_KEY);
  return result[STATE_KEY] ?? { kind: "idle" };
}
async function setState(state) {
  await chrome.storage.local.set({ [STATE_KEY]: state });
  broadcastState(state);
}
function broadcastState(state) {
  const payload = { type: "STATE_CHANGED", state };
  chrome.runtime.sendMessage(payload).catch(() => {
  });
  chrome.tabs.query({ url: "https://meet.google.com/*" }).then((tabs) => {
    for (const tab of tabs) {
      if (tab.id != null) {
        chrome.tabs.sendMessage(tab.id, payload).catch(() => {
        });
      }
    }
  }).catch(() => {
  });
}
async function getSettings() {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  const stored = result[SETTINGS_KEY] ?? {};
  return { ...DEFAULT_SETTINGS, ...stored };
}
async function setSettings(settings) {
  const current = await getSettings();
  await chrome.storage.local.set({
    [SETTINGS_KEY]: { ...current, ...settings }
  });
}

// src/background/api.ts
async function handleResponse(res, label) {
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`[api] ${label} failed ${res.status}: ${body}`);
  }
  return res.json();
}
function createCapApi(baseUrl, apiKey) {
  const authHeader = { Authorization: `Bearer ${apiKey}` };
  return {
    async createVideo({ recordingMode, name, extensionContext, meetingId }) {
      const url = new URL(`${baseUrl}/api/desktop/video/create`);
      url.searchParams.set("recordingMode", recordingMode);
      if (name) url.searchParams.set("name", name);
      if (extensionContext)
        url.searchParams.set("extensionContext", extensionContext);
      if (meetingId) url.searchParams.set("meetingId", meetingId);
      const res = await fetch(url.toString(), {
        headers: authHeader
      });
      return handleResponse(res, "createVideo");
    },
    async initiateMultipart({ contentType, videoId, subpath }) {
      const body = { contentType, videoId };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/initiate`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(
        res,
        "initiateMultipart"
      );
    },
    async presignPart({ uploadId, partNumber, videoId, subpath }) {
      const body = {
        uploadId,
        partNumber,
        videoId
      };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/presign-part`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(res, "presignPart");
    },
    async completeMultipart({ uploadId, parts, videoId, subpath }) {
      const body = { uploadId, parts, videoId };
      if (subpath) body.subpath = subpath;
      const res = await fetch(`${baseUrl}/api/upload/multipart/complete`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      return handleResponse(
        res,
        "completeMultipart"
      );
    },
    async recordingComplete({ videoId }) {
      const res = await fetch(`${baseUrl}/api/upload/recording-complete/`, {
        method: "POST",
        headers: { ...authHeader, "Content-Type": "application/json" },
        body: JSON.stringify({ videoId })
      });
      if (res.status === 400 || res.status === 409) {
        return;
      }
      await handleResponse(res, "recordingComplete");
    }
  };
}

// src/background/upload.ts
var MIN_PART_SIZE = 5 * 1024 * 1024;
var RETRY_QUEUE_KEY = "capExtRetryQueue";
var DEAD_LETTER_KEY = "capExtDeadLetterQueue";
var MAX_ATTEMPTS = 6;
var BACKOFF_SECONDS = [1, 4, 16, 64, 256];
var inMemoryBuffer = new Uint8Array(0);
function bytesToBase64(bytes) {
  let binary = "";
  const chunkSize = 32768;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}
function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}
function getPartRetryPayload(item) {
  const { partNumber, videoId, uploadId, partDataBase64 } = item.payload;
  if (typeof partNumber !== "number" || typeof videoId !== "string" || typeof uploadId !== "string" || typeof partDataBase64 !== "string") {
    return void 0;
  }
  return { partNumber, videoId, uploadId, partDataBase64 };
}
function upsertCompletedPart(parts, completedPart) {
  const withoutPart = parts.filter(
    (part) => part.PartNumber !== completedPart.PartNumber
  );
  return [...withoutPart, completedPart].sort(
    (a, b) => a.PartNumber - b.PartNumber
  );
}
function appendToBuffer(chunk) {
  const merged = new Uint8Array(inMemoryBuffer.length + chunk.length);
  merged.set(inMemoryBuffer, 0);
  merged.set(chunk, inMemoryBuffer.length);
  inMemoryBuffer = merged;
}
function drainBuffer() {
  const drained = inMemoryBuffer;
  inMemoryBuffer = new Uint8Array(0);
  return drained;
}
async function getRetryQueue() {
  const result = await chrome.storage.local.get(RETRY_QUEUE_KEY);
  return result[RETRY_QUEUE_KEY] ?? [];
}
async function setRetryQueue(queue) {
  await chrome.storage.local.set({ [RETRY_QUEUE_KEY]: queue });
}
async function addToRetryQueue(item) {
  const queue = await getRetryQueue();
  queue.push({ ...item, attempts: 0, nextRetryAt: Date.now() + 1e3 });
  await setRetryQueue(queue);
}
async function moveToDeadLetter(item) {
  const result = await chrome.storage.local.get(DEAD_LETTER_KEY);
  const dead = result[DEAD_LETTER_KEY] ?? [];
  dead.push(item);
  await chrome.storage.local.set({ [DEAD_LETTER_KEY]: dead });
  chrome.notifications.create({
    type: "basic",
    iconUrl: "/icons/icon-48.png",
    title: "data365 upload failed",
    message: "Upload failed \u2014 recording saved locally as fallback"
  });
}
async function requireSettings() {
  const settings = await getSettings();
  if (!settings.apiKey) {
    throw new Error("[upload] apiKey is not configured in extension settings");
  }
  return settings;
}
async function uploadPart(partData, partNumber, videoId, uploadId, settings) {
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const { presignedUrl } = await api.presignPart({
    uploadId,
    partNumber,
    videoId,
    subpath: "result.mp4"
  });
  const putRes = await fetch(presignedUrl, {
    method: "PUT",
    headers: { "Content-Type": "application/octet-stream" },
    body: partData
  });
  if (!putRes.ok) {
    const text = await putRes.text().catch(() => "");
    throw new Error(
      `[upload] PUT part ${partNumber} failed ${putRes.status}: ${text}`
    );
  }
  const etag = putRes.headers.get("ETag");
  return {
    ETag: etag ? etag.replace(/"/g, "") : "RESOLVE_SERVER_SIDE",
    PartNumber: partNumber
  };
}
async function recordCompletedPart(videoId, uploadId, completedPart, partSize) {
  const state = await getState();
  if (state.kind !== "recording" && state.kind !== "uploading" || state.videoId !== videoId || state.uploadId !== uploadId) {
    return;
  }
  const alreadyRecorded = state.parts.some(
    (part) => part.PartNumber === completedPart.PartNumber
  );
  await setState({
    ...state,
    parts: upsertCompletedPart(state.parts, completedPart),
    uploadedBytes: alreadyRecorded ? state.uploadedBytes : state.uploadedBytes + partSize
  });
}
function enqueuePartRetryPayload(partData, partNumber, videoId, uploadId) {
  return {
    kind: "part",
    payload: {
      partNumber,
      videoId,
      uploadId,
      partDataBase64: bytesToBase64(partData)
    }
  };
}
function scheduleRetry(item, now) {
  const nextAttempts = item.attempts + 1;
  if (nextAttempts >= MAX_ATTEMPTS) return void 0;
  const delaySec = BACKOFF_SECONDS[nextAttempts - 1] ?? 256;
  return {
    ...item,
    attempts: nextAttempts,
    nextRetryAt: now + delaySec * 1e3
  };
}
async function retryQueuedPartsForUpload(videoId, uploadId, parts, settings) {
  const queue = await getRetryQueue();
  const remaining = [];
  const now = Date.now();
  let nextParts = parts;
  let failed = false;
  for (const item of queue) {
    const payload = item.kind === "part" ? getPartRetryPayload(item) : void 0;
    if (item.kind !== "part") {
      remaining.push(item);
      continue;
    }
    if (!payload) {
      if (item.payload.videoId === videoId && item.payload.uploadId === uploadId) {
        failed = true;
        await moveToDeadLetter(item);
      } else {
        remaining.push(item);
      }
      continue;
    }
    if (payload.videoId !== videoId || payload.uploadId !== uploadId) {
      remaining.push(item);
      continue;
    }
    try {
      const partData = base64ToBytes(payload.partDataBase64);
      const completedPart = await uploadPart(
        partData,
        payload.partNumber,
        payload.videoId,
        payload.uploadId,
        settings
      );
      nextParts = upsertCompletedPart(nextParts, completedPart);
      await recordCompletedPart(
        payload.videoId,
        payload.uploadId,
        completedPart,
        partData.length
      );
    } catch (err) {
      console.error("[upload] Queued part retry failed:", err);
      failed = true;
      const rescheduled = scheduleRetry(item, now);
      if (rescheduled) {
        remaining.push(rescheduled);
      } else {
        await moveToDeadLetter({ ...item, attempts: item.attempts + 1 });
      }
    }
  }
  await setRetryQueue(remaining);
  return { parts: nextParts, failed };
}
async function initializeUpload(mode, meetingId) {
  const settings = await requireSettings();
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const now = /* @__PURE__ */ new Date();
  const dateStr = now.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });
  const name = mode === "meeting" && meetingId ? `data365 Meeting \u2014 ${meetingId}` : `data365 Recording \u2014 ${dateStr}`;
  const { id: videoId } = await api.createVideo({
    recordingMode: "extensionWeb",
    name,
    extensionContext: mode,
    meetingId
  });
  const { uploadId } = await api.initiateMultipart({
    contentType: "video/webm",
    videoId,
    subpath: "result.mp4"
  });
  inMemoryBuffer = new Uint8Array(0);
  return { videoId, uploadId };
}
async function handleChunk(chunk, _index, _mime) {
  const state = await getState();
  if (state.kind !== "recording") return;
  const data = new Uint8Array(chunk);
  appendToBuffer(data);
  const newTotalBytes = state.totalBytes + data.length;
  if (inMemoryBuffer.length >= MIN_PART_SIZE) {
    const partData = drainBuffer();
    const settings = await requireSettings();
    try {
      const completedPart = await uploadPart(
        partData,
        state.nextPartNumber,
        state.videoId,
        state.uploadId,
        settings
      );
      const freshState = await getState();
      if (freshState.kind !== "recording") return;
      await setState({
        ...freshState,
        parts: [...freshState.parts, completedPart],
        nextPartNumber: freshState.nextPartNumber + 1,
        totalBytes: newTotalBytes,
        uploadedBytes: freshState.uploadedBytes + partData.length
      });
    } catch (err) {
      console.error("[upload] Part upload failed:", err);
      await addToRetryQueue(
        enqueuePartRetryPayload(
          partData,
          state.nextPartNumber,
          state.videoId,
          state.uploadId
        )
      );
      const freshState = await getState();
      if (freshState.kind === "recording") {
        await setState({
          ...freshState,
          nextPartNumber: Math.max(
            freshState.nextPartNumber,
            state.nextPartNumber + 1
          ),
          totalBytes: newTotalBytes
        });
      }
    }
  } else {
    await setState({ ...state, totalBytes: newTotalBytes });
  }
}
async function finalizeUpload() {
  const state = await getState();
  if (state.kind !== "recording" && state.kind !== "uploading") return;
  const settings = await requireSettings();
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  let parts = [...state.parts];
  let nextPartNumber = state.kind === "recording" ? state.nextPartNumber : state.parts.length + 1;
  const totalBytes = state.totalBytes;
  const uploadedBytes = "uploadedBytes" in state ? state.uploadedBytes : 0;
  const { videoId, uploadId } = state;
  if (state.kind === "recording") {
    await setState({
      kind: "uploading",
      videoId,
      uploadId,
      parts,
      totalBytes,
      uploadedBytes
    });
  }
  const remaining = drainBuffer();
  if (remaining.length > 0) {
    try {
      const completedPart = await uploadPart(
        remaining,
        nextPartNumber,
        videoId,
        uploadId,
        settings
      );
      parts = [...parts, completedPart];
      nextPartNumber += 1;
    } catch (err) {
      console.error("[upload] Final part upload failed:", err);
      await addToRetryQueue(
        enqueuePartRetryPayload(remaining, nextPartNumber, videoId, uploadId)
      );
    }
  }
  const queuedPartsResult = await retryQueuedPartsForUpload(
    videoId,
    uploadId,
    parts,
    settings
  );
  parts = queuedPartsResult.parts;
  if (queuedPartsResult.failed) {
    await setState({
      kind: "error",
      reason: "Upload part retry failed. Check network and try again.",
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  if (parts.length === 0) {
    const bufferLen = remaining.length;
    console.error(
      `[upload] No parts uploaded \u2014 cannot complete multipart. totalBytes=${totalBytes}, remainingBuffer=${bufferLen}`
    );
    await setState({
      kind: "error",
      reason: totalBytes === 0 ? "No recording data was captured. Check screen-capture permissions and try again." : `Upload failed \u2014 ${totalBytes} bytes captured but no parts uploaded. Check network or try again.`,
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  await setState({ kind: "finishing", videoId });
  try {
    const apiParts = parts.map((p) => ({
      partNumber: p.PartNumber,
      etag: p.ETag,
      size: 0
    }));
    await api.completeMultipart({
      uploadId,
      parts: apiParts,
      videoId,
      subpath: "result.mp4"
    });
  } catch (err) {
    console.error("[upload] completeMultipart failed:", err);
    await addToRetryQueue({
      kind: "complete",
      payload: {
        uploadId,
        videoId,
        parts: parts.map((p) => ({
          partNumber: p.PartNumber,
          etag: p.ETag,
          size: 0
        }))
      }
    });
    await setState({
      kind: "error",
      reason: `Upload finalization failed: ${err instanceof Error ? err.message : String(err)}`,
      recoverable: true,
      previousVideoId: videoId
    });
    return;
  }
  try {
    await api.recordingComplete({ videoId });
  } catch (err) {
    console.error("[upload] recordingComplete failed:", err);
    await addToRetryQueue({
      kind: "recording-complete",
      payload: { videoId }
    });
  }
  const shareUrl = `${settings.apiBaseUrl}/s/${videoId}`;
  await setState({ kind: "complete", videoId, shareUrl });
}
async function retryPendingUploads() {
  const queue = await getRetryQueue();
  if (queue.length === 0) return;
  const settings = await getSettings();
  if (!settings.apiKey) return;
  const api = createCapApi(settings.apiBaseUrl, settings.apiKey);
  const now = Date.now();
  const remaining = [];
  for (const item of queue) {
    if (item.nextRetryAt > now) {
      remaining.push(item);
      continue;
    }
    try {
      if (item.kind === "part") {
        const payload = getPartRetryPayload(item);
        if (!payload) {
          await moveToDeadLetter(item);
          continue;
        }
        const partData = base64ToBytes(payload.partDataBase64);
        const completedPart = await uploadPart(
          partData,
          payload.partNumber,
          payload.videoId,
          payload.uploadId,
          settings
        );
        await recordCompletedPart(
          payload.videoId,
          payload.uploadId,
          completedPart,
          partData.length
        );
      } else if (item.kind === "complete") {
        const { uploadId, videoId, parts } = item.payload;
        await api.completeMultipart({
          uploadId,
          parts,
          videoId,
          subpath: "result.mp4"
        });
      } else if (item.kind === "recording-complete") {
        const { videoId } = item.payload;
        await api.recordingComplete({ videoId });
      }
    } catch (err) {
      console.error(`[upload] Retry failed for ${item.kind}:`, err);
      const rescheduled = scheduleRetry(item, now);
      if (!rescheduled) {
        await moveToDeadLetter({ ...item, attempts: item.attempts + 1 });
      } else {
        remaining.push(rescheduled);
      }
    }
  }
  await setRetryQueue(remaining);
}

// src/background/sw.ts
function getTabMediaStreamId(targetTabId) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabCapture.getMediaStreamId(
        { targetTabId },
        (streamId) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (!streamId) {
            reject(new Error("tabCapture returned no stream id"));
          } else {
            resolve(streamId);
          }
        }
      );
    } catch (err) {
      reject(err instanceof Error ? err : new Error(String(err)));
    }
  });
}
async function openInstructionRecorder() {
  const url = chrome.runtime.getURL("recorder.html");
  const existing = await chrome.tabs.query({ url });
  if (existing.length > 0 && existing[0].id != null) {
    await chrome.tabs.update(existing[0].id, { active: true });
    if (existing[0].windowId != null) {
      await chrome.windows.update(existing[0].windowId, { focused: true });
    }
    return existing[0].id;
  }
  const tab = await chrome.tabs.create({ url, active: true });
  return tab.id;
}
async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existingContexts.length > 0) return;
  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: [chrome.offscreen.Reason.USER_MEDIA],
    justification: "Recording screen/tab media"
  });
}
async function closeOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  if (existingContexts.length > 0) {
    await chrome.offscreen.closeDocument();
  }
}
function sendToOffscreen(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
function updateBadge(state) {
  switch (state.kind) {
    case "recording":
      chrome.action.setBadgeText({ text: "REC" });
      chrome.action.setBadgeBackgroundColor({ color: "#e53e3e" });
      break;
    case "uploading":
    case "finishing":
      chrome.action.setBadgeText({ text: "\u2191" });
      chrome.action.setBadgeBackgroundColor({ color: "#3182ce" });
      break;
    case "complete":
      chrome.action.setBadgeText({ text: "\u2713" });
      chrome.action.setBadgeBackgroundColor({ color: "#38a169" });
      break;
    case "error":
      chrome.action.setBadgeText({ text: "!" });
      chrome.action.setBadgeBackgroundColor({ color: "#dd6b20" });
      break;
    default:
      chrome.action.setBadgeText({ text: "" });
      break;
  }
}
function isInProgress(state) {
  return state.kind === "recording" || state.kind === "uploading" || state.kind === "finishing";
}
function isMessageBase(v) {
  return typeof v === "object" && v !== null && "type" in v && typeof v.type === "string";
}
function getString(obj, key) {
  const v = obj[key];
  return typeof v === "string" ? v : void 0;
}
function originOf(url) {
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}
function isTrustedTokenSender(senderUrl, configuredApiBaseUrl) {
  const sender = originOf(senderUrl);
  if (!sender) return false;
  const allowed = /* @__PURE__ */ new Set();
  const configured = originOf(configuredApiBaseUrl);
  if (configured) allowed.add(configured);
  const defaultOrigin = originOf(DEFAULT_API_BASE_URL);
  if (defaultOrigin) allowed.add(defaultOrigin);
  allowed.add("http://localhost:3000");
  allowed.add("http://localhost:3001");
  return allowed.has(sender);
}
function getNumber(obj, key) {
  const v = obj[key];
  return typeof v === "number" ? v : void 0;
}
var PENDING_MEET_START_KEY = "capPendingMeetStart";
var MIN_MEET_RECORDING_MS_BEFORE_AUTO_STOP = 1e4;
function isMeetUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    return parsed.hostname === "meet.google.com" && /^\/[a-z]+-[a-z]+-[a-z]+/.test(parsed.pathname);
  } catch {
    return false;
  }
}
async function resolveMeetSenderTabId(sender) {
  if (sender.tab?.id !== void 0 && isMeetUrl(sender.tab.url)) {
    return sender.tab.id;
  }
  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true,
    url: "https://meet.google.com/*"
  });
  const tab = tabs.find((t) => t.id !== void 0 && isMeetUrl(t.url));
  return tab?.id;
}
function isTabCaptureInvocationError(error) {
  const lower = error.toLowerCase();
  return lower.includes("not been invoked") || lower.includes("activetab") || lower.includes("active tab");
}
async function openPopupForPendingMeet(tabId, meetingId) {
  await chrome.storage.local.set({
    [PENDING_MEET_START_KEY]: { tabId, meetingId, createdAt: Date.now() }
  });
  try {
    if (typeof chrome.action?.openPopup === "function") {
      await chrome.action.openPopup();
      return true;
    }
  } catch {
  }
  await chrome.storage.local.remove(PENDING_MEET_START_KEY);
  return false;
}
async function finalizeRecording() {
  const state = await getState();
  if (state.kind !== "recording") return;
  const videoId = state.videoId;
  const uploadId = state.uploadId;
  const parts = state.parts;
  const totalBytes = state.totalBytes;
  const uploadedBytes = state.uploadedBytes;
  const nextState = {
    kind: "uploading",
    videoId,
    uploadId,
    parts,
    totalBytes,
    uploadedBytes
  };
  await setState(nextState);
  stopKeepAlive();
  updateBadge(nextState);
  await closeOffscreenDocument().catch(() => {
  });
  await finalizeUpload();
}
async function handleMessage(message, _sender) {
  if (!isMessageBase(message)) return { ok: false, error: "invalid message" };
  const msg = message;
  const type = msg.type;
  switch (type) {
    // ── Popup: start instruction recording ────────────────────────────
    // Full-screen instruction capture happens in a dedicated VISIBLE tab
    // (recorder.html) where getDisplayMedia() has a real user gesture. The
    // SW only opens that tab; the page owns the MediaStream and streams
    // chunks back via the RECORDER_* protocol. We deliberately do NOT enter
    // "arming" here — the actual gesture/picker lives in the recorder tab,
    // so state advances to "recording" only when that page sends
    // RECORDER_STARTED.
    case "START_INSTRUCTION": {
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        return { ok: false, error: "not signed in" };
      }
      await setState({ kind: "arming", mode: "instruction" });
      let recorderTabId;
      try {
        recorderTabId = await openInstructionRecorder();
      } catch (err) {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
        return {
          ok: false,
          error: `Couldn't open the recorder: ${err instanceof Error ? err.message : String(err)}`
        };
      }
      await setState({ kind: "arming", mode: "instruction", recorderTabId });
      return { ok: true };
    }
    // ── Popup: start meeting recording (Google Meet → tab capture) ────
    case "START_MEET": {
      const meetingId = getString(msg, "meetingId");
      const tabId = getNumber(msg, "tabId");
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      if (tabId === void 0) {
        return { ok: false, error: "No Meet tab to record" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        return { ok: false, error: "not signed in" };
      }
      await setState({ kind: "arming", mode: "meeting", meetingId, tabId });
      let meetStreamId;
      try {
        meetStreamId = await getTabMediaStreamId(tabId);
      } catch (err) {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
        return {
          ok: false,
          error: `Couldn't capture the meeting tab: ${err instanceof Error ? err.message : String(err)}`
        };
      }
      await ensureOffscreenDocument();
      await sendToOffscreen({
        type: "START_CAPTURE",
        streamId: meetStreamId,
        meetingId,
        tabId,
        micEnabled: settings.micEnabled,
        ...settings.micEnabled ? { micDeviceId: settings.micDeviceId } : {}
      });
      return { ok: true };
    }
    // ── Popup: stop ───────────────────────────────────────────────────
    case "STOP": {
      const stopState = await getState();
      const stopTabId = stopState.kind === "recording" && stopState.mode === "instruction" ? stopState.recorderTabId : stopState.kind === "arming" && stopState.mode === "instruction" ? stopState.recorderTabId : void 0;
      const contentStopTabId = stopState.kind === "recording" && stopState.contentRecorderTabId !== void 0 ? stopState.contentRecorderTabId : stopState.kind === "arming" && stopState.contentRecorderTabId !== void 0 ? stopState.contentRecorderTabId : void 0;
      if (stopTabId !== void 0) {
        chrome.tabs.sendMessage(stopTabId, { type: "STOP_CAPTURE" }).catch(() => {
        });
      } else if (contentStopTabId !== void 0) {
        chrome.tabs.sendMessage(contentStopTabId, { type: "STOP_CAPTURE" }).catch(() => {
        });
      } else {
        await sendToOffscreen({ type: "STOP_CAPTURE" });
      }
      return { ok: true };
    }
    // ── Popup: pause ──────────────────────────────────────────────────
    case "PAUSE": {
      const pauseState = await getState();
      const pauseTabId = pauseState.kind === "recording" && pauseState.mode === "instruction" ? pauseState.recorderTabId : void 0;
      if (pauseTabId !== void 0) {
        chrome.tabs.sendMessage(pauseTabId, { type: "PAUSE_CAPTURE" }).catch(() => {
        });
      } else if (pauseState.kind === "recording" && pauseState.contentRecorderTabId !== void 0) {
        chrome.tabs.sendMessage(pauseState.contentRecorderTabId, { type: "PAUSE_CAPTURE" }).catch(() => {
        });
      } else {
        await sendToOffscreen({ type: "PAUSE_CAPTURE" });
      }
      return { ok: true };
    }
    // ── Popup: resume ─────────────────────────────────────────────────
    case "RESUME": {
      const resumeState = await getState();
      const resumeTabId = resumeState.kind === "recording" && resumeState.mode === "instruction" ? resumeState.recorderTabId : void 0;
      if (resumeTabId !== void 0) {
        chrome.tabs.sendMessage(resumeTabId, { type: "RESUME_CAPTURE" }).catch(() => {
        });
      } else if (resumeState.kind === "recording" && resumeState.contentRecorderTabId !== void 0) {
        chrome.tabs.sendMessage(resumeState.contentRecorderTabId, { type: "RESUME_CAPTURE" }).catch(() => {
        });
      } else {
        await sendToOffscreen({ type: "RESUME_CAPTURE" });
      }
      return { ok: true };
    }
    // ── Recorder tab: instruction capture aborted before it began ─────
    // The visible recorder tab cancelled the screen picker or was closed
    // before recording started. Release the "arming" lock — but ONLY if we
    // are still arming an instruction, so an active recording (meeting or a
    // running instruction) is never disrupted.
    case "INSTRUCTION_CANCEL": {
      const state = await getState();
      if (state.kind === "arming" && state.mode === "instruction") {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
      }
      return { ok: true };
    }
    // ── Popup: cancel ─────────────────────────────────────────────────
    case "CANCEL": {
      const cancelState = await getState();
      const cancelTabId = cancelState.kind === "recording" && cancelState.mode === "instruction" ? cancelState.recorderTabId : cancelState.kind === "arming" && cancelState.mode === "instruction" ? cancelState.recorderTabId : void 0;
      const contentCancelTabId = cancelState.kind === "recording" && cancelState.contentRecorderTabId !== void 0 ? cancelState.contentRecorderTabId : cancelState.kind === "arming" && cancelState.contentRecorderTabId !== void 0 ? cancelState.contentRecorderTabId : void 0;
      if (cancelTabId !== void 0) {
        chrome.tabs.sendMessage(cancelTabId, { type: "STOP_CAPTURE" }).catch(() => {
        });
      } else if (contentCancelTabId !== void 0) {
        chrome.tabs.sendMessage(contentCancelTabId, { type: "STOP_CAPTURE" }).catch(() => {
        });
      } else {
        await sendToOffscreen({ type: "STOP_CAPTURE" }).catch(() => {
        });
      }
      await closeOffscreenDocument();
      await setState({ kind: "idle" });
      updateBadge({ kind: "idle" });
      return { ok: true };
    }
    // ── Popup / content: get state ────────────────────────────────────
    case "GET_STATE": {
      return await getState();
    }
    // ── Content: Meet call started ────────────────────────────────────
    case "MEET_CALL_STARTED": {
      const settings = await getSettings();
      if (settings.autoRecordOnMeet) {
        return {
          autoRecord: true,
          countdownSec: settings.autoRecordCountdownSec
        };
      }
      return { autoRecord: false };
    }
    // ── Content: Meet call ended ──────────────────────────────────────
    case "MEET_CALL_ENDED": {
      const meetingId = getString(msg, "meetingId");
      const senderTabId = _sender.tab?.id;
      const state = await getState();
      if (state.kind === "recording" && state.mode === "meeting" && state.meetingId === meetingId && (senderTabId === void 0 || state.tabId === senderTabId) && Date.now() - state.startedAt >= MIN_MEET_RECORDING_MS_BEFORE_AUTO_STOP) {
        if (state.contentRecorderTabId !== void 0) {
          chrome.tabs.sendMessage(state.contentRecorderTabId, { type: "STOP_CAPTURE" }).catch(() => {
          });
        } else {
          await sendToOffscreen({ type: "STOP_CAPTURE" });
        }
      }
      return { ok: true };
    }
    // ── Content: user clicked "Record now" nudge ──────────────────────
    case "MEET_NUDGE_RECORD_NOW": {
      const meetingId = getString(msg, "meetingId");
      const tabId = await resolveMeetSenderTabId(_sender);
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        try {
          if (typeof chrome.action?.openPopup === "function") {
            await chrome.action.openPopup().catch(() => {
              chrome.runtime.openOptionsPage();
            });
          } else {
            chrome.runtime.openOptionsPage();
          }
        } catch {
          chrome.runtime.openOptionsPage();
        }
        return { ok: false, error: "not signed in" };
      }
      if (tabId === void 0) {
        return { ok: false, error: "No Meet tab to record" };
      }
      await setState({ kind: "arming", mode: "meeting", meetingId, tabId });
      let nudgeStreamId;
      try {
        nudgeStreamId = await getTabMediaStreamId(tabId);
      } catch (err) {
        await setState({ kind: "idle" });
        updateBadge({ kind: "idle" });
        const error = err instanceof Error ? err.message : String(err);
        if (isTabCaptureInvocationError(error)) {
          const opened = await openPopupForPendingMeet(tabId, meetingId);
          if (opened) return { ok: true, openedPopup: true };
        }
        return {
          ok: false,
          error: `Couldn't capture the meeting tab: ${error}`
        };
      }
      await ensureOffscreenDocument();
      await sendToOffscreen({
        type: "START_CAPTURE",
        streamId: nudgeStreamId,
        meetingId,
        tabId,
        micEnabled: settings.micEnabled,
        ...settings.micEnabled ? { micDeviceId: settings.micDeviceId } : {}
      });
      return { ok: true };
    }
    // Content: the in-page Meet nudge already obtained a getDisplayMedia()
    // stream from the real button gesture. Prepare SW state so its following
    // RECORDER_STARTED message initializes a meeting upload, not instruction.
    case "MEET_NUDGE_CAPTURE_READY": {
      const meetingId = getString(msg, "meetingId");
      const tabId = await resolveMeetSenderTabId(_sender);
      const state = await getState();
      if (isInProgress(state)) {
        return { ok: false, error: "A recording is already in progress" };
      }
      const settings = await getSettings();
      if (!settings.apiKey) {
        try {
          if (typeof chrome.action?.openPopup === "function") {
            await chrome.action.openPopup().catch(() => {
              chrome.runtime.openOptionsPage();
            });
          } else {
            chrome.runtime.openOptionsPage();
          }
        } catch {
          chrome.runtime.openOptionsPage();
        }
        return { ok: false, error: "not signed in" };
      }
      if (tabId === void 0) {
        return { ok: false, error: "No Meet tab to record" };
      }
      await setState({
        kind: "arming",
        mode: "meeting",
        meetingId,
        tabId,
        contentRecorderTabId: tabId
      });
      return {
        ok: true,
        micEnabled: settings.micEnabled,
        micDeviceId: settings.micDeviceId
      };
    }
    case "MEET_NUDGE_LATER":
    case "MEET_NUDGE_DISMISS":
      return { ok: true };
    // ── Content: settings query ───────────────────────────────────────
    case "GET_SETTINGS": {
      const settings = await getSettings();
      return {
        autoRecordOnMeet: settings.autoRecordOnMeet,
        autoRecordCountdownSec: settings.autoRecordCountdownSec,
        soundEnabled: settings.soundEnabled
      };
    }
    // ── Offscreen: recorder started ───────────────────────────────────
    case "RECORDER_STARTED": {
      const mime = getString(msg, "mime") ?? "video/webm";
      const state = await getState();
      const mode = state.kind === "arming" ? state.mode : "instruction";
      const meetingId = state.kind === "arming" ? state.meetingId : void 0;
      const tabId = state.kind === "arming" ? state.tabId : void 0;
      const recorderTabId = state.kind === "arming" ? state.recorderTabId : void 0;
      const contentRecorderTabId = state.kind === "arming" ? state.contentRecorderTabId : void 0;
      let videoId;
      let uploadId;
      try {
        const result = await initializeUpload(mode, meetingId);
        videoId = result.videoId;
        uploadId = result.uploadId;
      } catch (err) {
        console.error("[sw] initializeUpload failed:", err);
        const errState = {
          kind: "error",
          reason: `Failed to initialize upload: ${err instanceof Error ? err.message : String(err)}`,
          recoverable: true
        };
        await setState(errState);
        updateBadge(errState);
        await closeOffscreenDocument().catch(() => {
        });
        return { ok: false, error: "initializeUpload failed" };
      }
      const nextState = {
        kind: "recording",
        mode,
        videoId,
        uploadId,
        startedAt: Date.now(),
        parts: [],
        nextPartNumber: 1,
        totalBytes: 0,
        uploadedBytes: 0,
        meetingId,
        tabId,
        mime,
        paused: false,
        recorderTabId,
        contentRecorderTabId
      };
      await setState(nextState);
      startKeepAlive();
      updateBadge(nextState);
      return { ok: true };
    }
    // ── Offscreen: data chunk ─────────────────────────────────────────
    case "RECORDER_CHUNK": {
      const raw = msg.chunk;
      const index = getNumber(msg, "index") ?? 0;
      const mime = getString(msg, "mime") ?? "video/webm";
      if (raw && Array.isArray(raw) && raw.length > 0) {
        await handleChunk(new Uint8Array(raw).buffer, index, mime);
      }
      return { ok: true };
    }
    // ── Offscreen: recorder stopped ───────────────────────────────────
    case "RECORDER_STOPPED": {
      await finalizeRecording();
      return { ok: true };
    }
    // ── Offscreen: recorder error ─────────────────────────────────────
    case "RECORDER_ERROR": {
      const error = getString(msg, "error") ?? "Unknown recorder error";
      const state = await getState();
      const previousVideoId = state.kind === "recording" ? state.videoId : void 0;
      const nextState = {
        kind: "error",
        reason: error,
        recoverable: true,
        previousVideoId
      };
      await setState(nextState);
      stopKeepAlive();
      updateBadge(nextState);
      await closeOffscreenDocument().catch(() => {
      });
      chrome.notifications.create("recorder-error", {
        type: "basic",
        iconUrl: "icons/icon-128.png",
        title: "Recording error",
        message: error
      });
      return { ok: true };
    }
    // ── Popup: retry after error ──────────────────────────────────────
    case "RETRY": {
      const state = await getState();
      if (state.kind !== "error")
        return { ok: false, error: "not in error state" };
      await setState({ kind: "idle" });
      updateBadge({ kind: "idle" });
      return { ok: true };
    }
    // ── Options: save settings ────────────────────────────────────────
    case "SAVE_SETTINGS": {
      const settings = msg.settings;
      if (settings) {
        await setSettings(settings);
      }
      return { ok: true };
    }
    // ── Options: get all settings ─────────────────────────────────────
    case "GET_ALL_SETTINGS": {
      return await getSettings();
    }
    // ── Sign-in-with-Cap token from options page ──────────────────────
    case "CAP_EXTENSION_TOKEN": {
      const token = getString(msg, "token");
      const apiBaseUrl = getString(msg, "apiBaseUrl");
      if (token) {
        await setSettings({
          apiKey: token,
          ...apiBaseUrl ? { apiBaseUrl } : {}
        });
      }
      return { ok: true };
    }
    default:
      return { ok: false, error: `unknown message type: ${type}` };
  }
}
chrome.runtime.onMessageExternal.addListener(
  (message, _sender, sendResponse) => {
    if (!isMessageBase(message)) {
      sendResponse({ ok: false });
      return false;
    }
    const msg = message;
    if (msg.type === "CAP_EXTENSION_TOKEN") {
      const token = getString(msg, "token");
      const apiBaseUrl = getString(msg, "apiBaseUrl");
      getSettings().then((settings) => {
        if (!isTrustedTokenSender(_sender.url, settings.apiBaseUrl)) {
          console.warn(
            "Rejected CAP_EXTENSION_TOKEN from untrusted origin:",
            _sender.url
          );
          sendResponse({ ok: false, error: "untrusted origin" });
          return;
        }
        if (apiBaseUrl) {
          const senderOrigin = originOf(_sender.url);
          const requestedOrigin = originOf(apiBaseUrl);
          if (!senderOrigin || !requestedOrigin || senderOrigin !== requestedOrigin) {
            console.warn(
              "Rejected CAP_EXTENSION_TOKEN: apiBaseUrl origin mismatch",
              { senderOrigin, requestedOrigin }
            );
            sendResponse({
              ok: false,
              error: "apiBaseUrl/origin mismatch"
            });
            return;
          }
        }
        setSettings({
          apiKey: token ?? "",
          ...apiBaseUrl ? { apiBaseUrl } : {}
        }).then(() => {
          chrome.runtime.sendMessage({ type: "CAP_EXTENSION_TOKEN", token, apiBaseUrl }).catch(() => {
          });
          sendResponse({ ok: true });
        });
      }).catch(() => {
        sendResponse({ ok: false, error: "settings read failed" });
      });
      return true;
    }
    sendResponse({ ok: false });
    return false;
  }
);
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    handleMessage(message, sender).then(sendResponse).catch((err) => {
      const msg = err instanceof Error ? err.message : String(err);
      sendResponse({ ok: false, error: msg });
    });
    return true;
  }
);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (isKeepAliveAlarm(alarm.name)) {
    chrome.storage.local.get("capExtState");
  }
});
chrome.runtime.onStartup.addListener(async () => {
  const state = await getState();
  if (state.kind === "recording") {
    chrome.notifications.create("recording-interrupted", {
      type: "basic",
      iconUrl: "icons/icon-128.png",
      title: "Recording interrupted",
      message: "The browser restarted during recording. Uploading what was captured..."
    });
    const nextState = {
      kind: "uploading",
      videoId: state.videoId,
      uploadId: state.uploadId,
      parts: state.parts,
      totalBytes: state.totalBytes,
      uploadedBytes: state.uploadedBytes
    };
    await setState(nextState);
    updateBadge(nextState);
  }
  if (state.kind === "recording" || state.kind === "uploading") {
    startKeepAlive();
  }
  await retryPendingUploads();
});
chrome.runtime.onInstalled.addListener(async () => {
  const state = await getState();
  updateBadge(state);
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.kind === "arming" && state.mode === "instruction" && state.recorderTabId === tabId) {
    await setState({ kind: "idle" });
    updateBadge({ kind: "idle" });
  } else if (state.kind === "recording" && state.mode === "instruction" && state.recorderTabId === tabId) {
    await finalizeRecording().catch(() => {
    });
  }
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await getState();
  if (state.kind === "arming" && state.mode === "meeting" && state.contentRecorderTabId === tabId) {
    await setState({ kind: "idle" });
    updateBadge({ kind: "idle" });
  } else if (state.kind === "recording" && state.mode === "meeting" && state.contentRecorderTabId === tabId) {
    await finalizeRecording().catch(() => {
    });
  }
});
//# sourceMappingURL=background.js.map
